<?php defined('BASEPATH') OR exit('No direct script access allowed');
msg('success delete cache','success');