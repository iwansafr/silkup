<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class="col-md-3">
  <?php
  $this->load->view('pos_edit');
  ?>
</div>
<div class="col-md-9">
  <?php
  $this->load->view('pos_list');
  ?>
</div>