<script src="<?php echo base_url('templates/AdminLTE/');?>bower_components/jquery/dist/jquery.min.js"></script>
<script src="<?php echo base_url('templates/AdminLTE/');?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo base_url('templates/AdminLTE/');?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url('templates/AdminLTE/');?>bower_components/fastclick/lib/fastclick.js"></script>
<script src="<?php echo base_url('templates/AdminLTE/');?>dist/js/adminlte.min.js"></script>
<script src="<?php echo base_url('templates/AdminLTE/');?>dist/js/demo.js"></script>